import React from 'react';
import FormularioAuth from '../components/FormularioAuth';

const InicioSesion = () => {
  return (
    <div>
      <FormularioAuth registro={false}/>
    </div>
  )
}

export default InicioSesion

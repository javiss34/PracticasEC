import React from 'react'
import FormularioCrearListas from '../components/FormularioCrearListas.jsx'

const InsertarListas = () => {
  return (
    <div>
      <FormularioCrearListas/>
    </div>
  )
}

export default InsertarListas

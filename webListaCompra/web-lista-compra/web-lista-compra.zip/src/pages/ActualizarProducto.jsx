import React from 'react'
import FormularioInsertarProductos from '../components/FormularioInsertarProductos'

const ActualizarProducto = () => {

  return (
    <>
      <FormularioInsertarProductos/>
    </>
  )
}

export default ActualizarProducto

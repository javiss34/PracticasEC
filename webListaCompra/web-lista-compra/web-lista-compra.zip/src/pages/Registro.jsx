import React from 'react'
import FormularioAuth from '../components/FormularioAuth'

const Registro = () => {
  return (
    <div>
      <FormularioAuth registro={true}/>
    </div>
  )
}

export default Registro

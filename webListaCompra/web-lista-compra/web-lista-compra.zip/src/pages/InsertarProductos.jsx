import React from 'react';
import FormularioInsertarProductos from '../components/FormularioInsertarProductos';

const InsertarProductos = () => {
  return (
    <div>
      <FormularioInsertarProductos/>
    </div>
  )
}

export default InsertarProductos

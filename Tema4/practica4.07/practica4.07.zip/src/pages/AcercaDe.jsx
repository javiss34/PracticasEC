import React from 'react'

const AcercaDe = () => {
  return (
    <div>
      <p>Práctica 4.07 de React</p>
      <p>Javier Sánchez Solera</p>
      <p>Fecha modificación: 27/10/2025</p>
    </div>
  )
}

export default AcercaDe

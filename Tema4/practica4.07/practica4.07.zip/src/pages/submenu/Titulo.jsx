import React from 'react';



const Titulo = () => {
  return (
    <div>
        <h2>Carteleras filtradas por título</h2>
    </div>
  )
}

export default Titulo

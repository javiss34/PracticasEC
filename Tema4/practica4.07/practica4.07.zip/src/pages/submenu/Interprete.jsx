import React from 'react';
import MostrarCarteleras from '../../components/MostrarCarteleras';

const Interprete = () => {
  return (
    <div>
        <h2>Carteleras filtradas por interprete</h2>
    </div>
  )
}

export default Interprete

import React from 'react';

const Director = () => {
  return (
    <div>
        <h2>Carteleras filtradas por director</h2>
    </div>
  )
}

export default Director

import React, { useState } from 'react';


const Inicio = () => {

  return (
    <>
      <h2>Esta es la página de inicio</h2>
    </>
  )
}

export default Inicio

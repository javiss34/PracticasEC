import React from 'react';

const Taquilla = ({recaudacion}) => {
  return (
    <>
        <h3>{recaudacion}</h3>
    </>
  )
}

export default Taquilla

import React from 'react'

const Inicio = () => {
  return (
    <div>
      <h2>Esta es la página de inicio</h2>
    </div>
  )
}

export default Inicio

import React from 'react';
import BotonInicio from '../components/BotonInicio.jsx';

const AcercaDe = () => {
  return (
    <>
      <p>Esta es práctica 4.06 Interfaces con rutas en react.</p>
      <BotonInicio/>
    </>

  )
}

export default AcercaDe
